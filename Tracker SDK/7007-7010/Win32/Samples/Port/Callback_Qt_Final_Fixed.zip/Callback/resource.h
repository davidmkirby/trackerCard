//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Callback.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CALLBACK_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_STATE                       1040
#define IDC_STATUS                      1041
#define IDC_ERROR_X                     1042
#define IDC_ERROR_Y                     1043
#define IDC_TARGETSIZE_X                1044
#define IDC_TARGETSIZE_Y                1045
#define IDC_MOUNT_AZ                    1047
#define IDC_MOUNT_EL                    1048
#define IDC_STATE2                      1049
#define IDC_DATA_UPDATE                 1050
#define IDC_MESSAGE_RATE                1051
#define IDC_STATUS2                     1055
#define IDC_ERROR_X2                    1059
#define IDC_ERROR_Y2                    1060
#define IDC_TARGETSIZE_X2               1061
#define IDC_TARGETSIZE_Y2               1062
#define IDC_TARGETCOUNT                 1065
#define IDC_FILTERED_ERROR_X            1066
#define IDC_FILTERED_ERROR_Y            1067
#define IDC_TARGETCOUNT2                1068
#define IDC_FILTERED_ERROR_X2           1069
#define IDC_FILTERED_ERROR_Y2           1070
#define IDC_OUTPUT_COMMAND              1115
#define IDC_OUTPUT_60HZ                 1116

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
